# Daniyal Asif — Portfolio

Portfolio of Daniyal Asif, a frontend developer working with React, TypeScript and GSAP.

The interface is an editorial, grid-aligned layout in strict grayscale, with uppercase display headings, monospaced body text and a single easing curve, `cubic-bezier(0.16, 1, 0.3, 1)`, used for every transition.

## Stack

- Vite, React 18, TypeScript
- Tailwind CSS and shadcn/ui (Radix)
- GSAP (with ScrollTrigger and CustomEase) for entry, scroll and hover motion
- Framer Motion for route-level components
- Supabase for projects, skills and site settings
- EmailJS for the contact form
- React Router, React Query, Redux Toolkit, React Hook Form, Zod

## Getting started

```bash
npm install
npm run dev
```

The dev server runs on port 8080. Supabase and EmailJS credentials go in a local `.env` file; see `src/integrations/` for the variables the app reads. Do not commit `.env`.

## Scripts

| Command | What it does |
| --- | --- |
| `npm run dev` | Start the dev server |
| `npm run build` | Production build |
| `npm run build:dev` | Development-mode build |
| `npm run preview` | Preview the production build |
| `npm run lint` | Run ESLint |

## Design system

- **Palette:** `#FFFFFF`, `#0A0A0A` and neutral grays, defined as HSL tokens in `src/index.css`
- **Type:** Space Grotesk for uppercase, wide-tracked headings; JetBrains Mono for body text
- **Motion:** one easing curve, `0.05s` text stagger, and only `transform` and `opacity` animate on scroll. Shared helpers live in `src/lib/motion.ts`
- **Accessibility:** `prefers-reduced-motion` disables GSAP animation and shortens CSS transitions

Motion rules for AI-assisted work are in `.claude/skills/motion-principles/SKILL.md`.

## Project structure

```
src/
  components/   Navbar, Footer, ProjectCard, SkillCircle, ui/
  hooks/        useSkills, useSiteSettings
  integrations/ Supabase client
  lib/          motion helpers, utils
  pages/        Index, About, Skills, Projects, ProjectDetail, GitHub, Contact
public/         CV, favicon, robots.txt, sitemap.xml
```

## Deployment

The build output is a static site (`dist/`) and works on Vercel, Netlify, Cloudflare Pages or any static host. Configure the same environment variables there.

## Contact

[GitHub](https://github.com/DaniyalAsif7778) · [LinkedIn](https://linkedin.com/in/DaniyalAsif7778)
