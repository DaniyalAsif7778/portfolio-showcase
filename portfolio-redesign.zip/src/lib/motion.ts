import { gsap } from 'gsap';
import { CustomEase } from 'gsap/CustomEase';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

export const EASE_NAME = 'premium';
export const EASE_CSS = 'cubic-bezier(0.16, 1, 0.3, 1)';
export const EASE_FM: [number, number, number, number] = [0.16, 1, 0.3, 1];
export const STAGGER = 0.05;

let ready = false;

export function registerMotion() {
  if (ready) return;
  gsap.registerPlugin(CustomEase, ScrollTrigger);
  CustomEase.create(EASE_NAME, '0.16, 1, 0.3, 1');
  gsap.defaults({ ease: EASE_NAME, duration: 1.2 });
  ready = true;
}

export const prefersReducedMotion = () =>
  typeof window !== 'undefined' &&
  window.matchMedia('(prefers-reduced-motion: reduce)').matches;
