import { useEffect, useLayoutEffect, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowUpRight } from 'lucide-react';
import { gsap } from 'gsap';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import profileAsset from '@/assets/daniyal-photo.png.asset.json';
import { useSkills } from '@/hooks/useSkills';
import { useSiteSettings } from '@/hooks/useSiteSettings';
import { supabase } from '@/integrations/supabase/client';
import { registerMotion, prefersReducedMotion, STAGGER } from '@/lib/motion';

registerMotion();

interface FeaturedProject {
  title: string;
  tech_stack: string[] | null;
  slug: string;
}

const Index = () => {
  const root = useRef<HTMLDivElement>(null);
  const { skills: all } = useSkills();
  const { settings } = useSiteSettings();
  const [projects, setProjects] = useState<FeaturedProject[]>([]);

  const featured = all.filter((s) => s.featured);
  const skills = (featured.length ? featured : all).slice(0, 6);
  const nameLines = (settings.name || '').split(' ').filter(Boolean);

  useEffect(() => {
    const load = async () => {
      const { data } = await supabase
        .from('projects')
        .select('title, tech_stack, slug')
        .order('created_at', { ascending: false })
        .limit(4);
      setProjects((data as FeaturedProject[]) || []);
    };
    load();
  }, []);

  // Page entry: one orchestrated sequence, 0.05s stagger per line
  useLayoutEffect(() => {
    if (prefersReducedMotion()) return;
    const ctx = gsap.context(() => {
      gsap.from('[data-line]', { yPercent: 110, stagger: STAGGER, duration: 1.4, delay: 0.1, clearProps: 'transform' });
      gsap.from('[data-fade]', { y: 24, opacity: 0, stagger: STAGGER, delay: 0.35, clearProps: 'opacity,transform' });
      gsap.from('[data-portrait]', { y: 40, opacity: 0, duration: 1.6, delay: 0.3, clearProps: 'opacity,transform' });
    }, root);
    return () => ctx.revert();
  }, []);

  // Scroll reveals: transform and opacity only, so layout never shifts
  useLayoutEffect(() => {
    if (prefersReducedMotion()) return;
    const ctx = gsap.context(() => {
      gsap.utils.toArray<HTMLElement>('[data-section]', root.current).forEach((section) => {
        gsap.from(section.querySelectorAll('[data-rise]'), {
          y: 32,
          opacity: 0,
          stagger: STAGGER * 2,
          clearProps: 'opacity,transform',
          scrollTrigger: { trigger: section, start: 'top 80%', once: true },
        });
      });
      gsap.utils.toArray<HTMLElement>('[data-bar]', root.current).forEach((bar) => {
        gsap.fromTo(
          bar,
          { scaleX: 0 },
          {
            scaleX: Number(bar.dataset.value) / 100,
            duration: 1.6,
            scrollTrigger: { trigger: bar, start: 'top 92%', once: true },
          }
        );
      });
    }, root);
    return () => ctx.revert();
  }, [projects.length, skills.length]);

  // Hover: staggered translate on the row's parts, subtle tracking change on the label
  const onEnter = (e: React.MouseEvent<HTMLElement>) => {
    if (prefersReducedMotion()) return;
    const row = e.currentTarget;
    gsap.to(row.querySelectorAll('[data-h]'), { x: 14, stagger: STAGGER, duration: 0.6, overwrite: 'auto' });
    gsap.to(row.querySelectorAll('[data-track]'), { letterSpacing: '0.26em', duration: 0.6, overwrite: 'auto' });
  };
  const onLeave = (e: React.MouseEvent<HTMLElement>) => {
    if (prefersReducedMotion()) return;
    const row = e.currentTarget;
    gsap.to(row.querySelectorAll('[data-h]'), { x: 0, stagger: STAGGER / 2, duration: 0.6, overwrite: 'auto' });
    gsap.to(row.querySelectorAll('[data-track]'), { letterSpacing: '0.18em', duration: 0.6, overwrite: 'auto' });
  };

  return (
    <div ref={root} className="min-h-screen bg-background">
      <Navbar />

      <main>
        {/* Hero: off-center canvas, headline starts at column 4 */}
        <section className="canvas pt-40 pb-24 gap-y-16">
          <aside className="col-span-12 md:col-span-3 eyebrow space-y-1" data-fade>
            <p>{settings.badge}</p>
          </aside>

          <h1 className="col-span-12 md:col-span-9 md:col-start-4 display text-[clamp(2.75rem,10vw,9.5rem)]">
            {nameLines.map((line) => (
              <span key={line} className="line-mask">
                <span data-line className="block">{line}</span>
              </span>
            ))}
          </h1>

          <div className="col-span-8 md:col-span-3 md:row-start-3" data-portrait>
            <img
              src={settings.profile_image || profileAsset.url}
              alt={settings.name}
              className="w-full aspect-[4/5] object-cover grayscale"
            />
          </div>

          <div className="col-span-12 md:col-span-6 md:col-start-4 md:row-start-3 self-end">
            <p className="eyebrow text-foreground mb-6" data-fade>{settings.tagline}</p>
            <p className="max-w-md" data-fade>{settings.intro}</p>
            <div className="mt-10 flex flex-wrap gap-x-10 gap-y-4" data-fade>
              <a href="/Daniyal_Asif_CV.pdf" download="Daniyal_Asif_CV.pdf" className="link-ink">Download CV</a>
              <a href={settings.github_url} target="_blank" rel="noopener noreferrer" className="link-ink">GitHub</a>
              <a href={settings.linkedin_url} target="_blank" rel="noopener noreferrer" className="link-ink">LinkedIn</a>
            </div>
          </div>
        </section>

        {/* Selected work */}
        <section data-section className="canvas rule py-24 gap-y-10">
          <h2 className="col-span-12 md:col-span-3 eyebrow" data-rise>Selected work</h2>

          <div className="col-span-12 md:col-span-9 md:col-start-4 work-list">
            {projects.map((p) => (
              <div key={p.slug} data-rise>
                <Link
                  to={`/projects/${p.slug}`}
                  onMouseEnter={onEnter}
                  onMouseLeave={onLeave}
                  className="work-row group grid grid-cols-12 items-center gap-x-6 gap-y-2 border-b border-border py-8"
                >
                  <span data-h className="col-span-12 md:col-span-7 display text-xl md:text-2xl">{p.title}</span>
                  <span data-h data-track className="col-span-10 md:col-span-4 eyebrow truncate">
                    {(p.tech_stack || []).slice(0, 3).join(' / ')}
                  </span>
                  <ArrowUpRight
                    size={18}
                    className="col-span-2 md:col-span-1 justify-self-end opacity-0 -translate-x-2 transition-all duration-[600ms] ease-[cubic-bezier(0.16,1,0.3,1)] group-hover:opacity-100 group-hover:translate-x-0"
                  />
                </Link>
              </div>
            ))}

            <div className="pt-10" data-rise>
              <Link to="/projects" className="link-ink">All projects</Link>
            </div>
          </div>
        </section>

        {/* Core skills */}
        <section data-section className="canvas rule py-24 gap-y-10">
          <h2 className="col-span-12 md:col-span-3 eyebrow" data-rise>Core skills</h2>

          <div className="col-span-12 md:col-span-9 md:col-start-4 grid md:grid-cols-2 gap-x-16 gap-y-10">
            {skills.map((skill) => (
              <div key={skill.id} data-rise>
                <div className="flex justify-between eyebrow text-foreground">
                  <span>{skill.name}</span>
                  <span>{skill.percentage}%</span>
                </div>
                <div className="mt-3 h-[2px] bg-border">
                  <div
                    data-bar
                    data-value={skill.percentage}
                    className="h-[2px] bg-foreground origin-left"
                    style={{ transform: `scaleX(${skill.percentage / 100})` }}
                  />
                </div>
              </div>
            ))}

            <div className="md:col-span-2 pt-4" data-rise>
              <Link to="/skills" className="link-ink">All skills</Link>
            </div>
          </div>
        </section>

        {/* Contact */}
        <section data-section className="canvas rule py-32 gap-y-10">
          <h2 className="col-span-12 md:col-span-3 eyebrow" data-rise>Contact</h2>
          <div className="col-span-12 md:col-span-9 md:col-start-4" data-rise>
            <Link to="/contact" className="display text-[clamp(2rem,6vw,5rem)] hover:tracking-[0.16em] block">
              Let’s work together
            </Link>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
};

export default Index;
