import { motion } from 'framer-motion';
import { EASE_FM } from '@/lib/motion';

interface SkillCircleProps {
  name: string;
  percentage: number;
  /** Kept for API compatibility; the redesign is monochrome so it is ignored. */
  color?: string;
  delay?: number;
}

const SkillCircle = ({ name, percentage, delay = 0 }: SkillCircleProps) => {
  const circumference = 2 * Math.PI * 45;
  const strokeDashoffset = circumference - (percentage / 100) * circumference;

  return (
    <motion.div
      initial={{ opacity: 0, y: 24 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 1, delay, ease: EASE_FM }}
      viewport={{ once: true }}
      className="flex flex-col items-center gap-4"
    >
      <div className="relative w-28 h-28">
        <svg className="w-full h-full -rotate-90" viewBox="0 0 112 112" aria-hidden="true">
          <circle cx="56" cy="56" r="45" stroke="hsl(var(--border))" strokeWidth="1" fill="transparent" />
          <motion.circle
            cx="56"
            cy="56"
            r="45"
            stroke="hsl(var(--foreground))"
            strokeWidth="2"
            fill="transparent"
            strokeDasharray={circumference}
            initial={{ strokeDashoffset: circumference }}
            whileInView={{ strokeDashoffset }}
            transition={{ duration: 1.6, delay: delay + 0.2, ease: EASE_FM }}
            viewport={{ once: true }}
          />
        </svg>
        <div className="absolute inset-0 flex items-center justify-center">
          <span className="text-sm font-medium">{percentage}%</span>
        </div>
      </div>
      <span className="eyebrow">{name}</span>
    </motion.div>
  );
};

export default SkillCircle;
