import { Link } from 'react-router-dom';
import { Github, Linkedin, Mail } from 'lucide-react';
import { useSiteSettings } from '@/hooks/useSiteSettings';

const iconLink =
  'text-muted-foreground hover:text-foreground transition-all duration-[600ms] ease-[cubic-bezier(0.16,1,0.3,1)]';

const Footer = () => {
  const { settings } = useSiteSettings();

  return (
    <footer className="rule">
      <div className="canvas py-12 gap-y-8 items-start">
        <p className="col-span-12 md:col-span-3 eyebrow">
          © {new Date().getFullYear()} {settings.name}
        </p>

        <nav className="col-span-12 md:col-span-5 md:col-start-4 flex flex-wrap gap-x-8 gap-y-2">
          <Link to="/privacy" className="nav-link">Privacy</Link>
          <Link to="/terms" className="nav-link">Terms</Link>
        </nav>

        <div className="col-span-12 md:col-span-3 md:col-start-10 flex md:justify-end gap-6">
          <a href={settings.github_url} target="_blank" rel="noopener noreferrer" aria-label="GitHub profile" className={iconLink}>
            <Github size={18} />
          </a>
          <a href={settings.linkedin_url} target="_blank" rel="noopener noreferrer" aria-label="LinkedIn profile" className={iconLink}>
            <Linkedin size={18} />
          </a>
          <a
            href={settings.about.email ? `mailto:${settings.about.email}` : '#'}
            aria-label="Send email"
            className={iconLink}
          >
            <Mail size={18} />
          </a>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
