import { motion } from 'framer-motion';
import { EASE_FM } from '@/lib/motion';

interface SectionHeaderProps {
  title: string;
  subtitle?: string;
  as?: 'h1' | 'h2';
}

const SectionHeader = ({ title, subtitle, as = 'h2' }: SectionHeaderProps) => {
  const Heading = as;
  return (
    <motion.div
      initial={{ opacity: 0, y: 24 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 1, ease: EASE_FM }}
      viewport={{ once: true }}
      className="max-w-5xl mx-auto mb-16"
    >
      <Heading className="display text-4xl md:text-6xl mb-5">{title}</Heading>
      {subtitle && <p className="text-sm text-muted-foreground max-w-xl">{subtitle}</p>}
    </motion.div>
  );
};

export default SectionHeader;
