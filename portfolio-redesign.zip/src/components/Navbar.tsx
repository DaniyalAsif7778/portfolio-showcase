import { NavLink as RouterNavLink } from 'react-router-dom';
import { motion } from 'framer-motion';
import { useState } from 'react';
import { Menu, X } from 'lucide-react';
import { useSiteSettings } from '@/hooks/useSiteSettings';
import { EASE_FM } from '@/lib/motion';

const navItems = [
  { path: '/', label: 'Home' },
  { path: '/about', label: 'About' },
  { path: '/skills', label: 'Skills' },
  { path: '/projects', label: 'Projects' },
  { path: '/github', label: 'GitHub' },
  { path: '/contact', label: 'Contact' },
];

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);
  const { settings } = useSiteSettings();

  return (
    <motion.nav
      initial={{ y: -24, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 1, ease: EASE_FM }}
      className="fixed top-0 left-0 right-0 z-50 border-b border-border bg-background/85 backdrop-blur-md"
    >
      <div className="px-[clamp(24px,6vw,96px)] py-5">
        <div className="flex items-center justify-between">
          <RouterNavLink to="/" className="display text-sm" onClick={() => setIsOpen(false)}>
            {settings.name}
          </RouterNavLink>

          <div className="hidden md:flex items-center gap-10">
            {navItems.map((item) => (
              <RouterNavLink
                key={item.path}
                to={item.path}
                end={item.path === '/'}
                className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}
              >
                {item.label}
              </RouterNavLink>
            ))}
          </div>

          <button
            onClick={() => setIsOpen(!isOpen)}
            className="md:hidden p-2 -mr-2 text-foreground"
            aria-label={isOpen ? 'Close menu' : 'Open menu'}
            aria-expanded={isOpen}
          >
            {isOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>

        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: -8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, ease: EASE_FM }}
            className="md:hidden mt-6 pb-2"
          >
            <div className="flex flex-col gap-5">
              {navItems.map((item) => (
                <RouterNavLink
                  key={item.path}
                  to={item.path}
                  end={item.path === '/'}
                  onClick={() => setIsOpen(false)}
                  className={({ isActive }) => `nav-link self-start ${isActive ? 'active' : ''}`}
                >
                  {item.label}
                </RouterNavLink>
              ))}
            </div>
          </motion.div>
        )}
      </div>
    </motion.nav>
  );
};

export default Navbar;
