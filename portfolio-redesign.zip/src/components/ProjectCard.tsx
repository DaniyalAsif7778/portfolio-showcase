import { motion } from 'framer-motion';
import { ExternalLink, Github } from 'lucide-react';
import { Link } from 'react-router-dom';
import { EASE_FM } from '@/lib/motion';

interface ProjectCardProps {
  title: string;
  description: string;
  techStack: string[];
  githubUrl?: string;
  liveUrl?: string;
  slug?: string;
  delay?: number;
}

const iconLink =
  'text-muted-foreground hover:text-foreground transition-all duration-[600ms] ease-[cubic-bezier(0.16,1,0.3,1)]';

const ProjectCard = ({ title, description, techStack, githubUrl, liveUrl, slug, delay = 0 }: ProjectCardProps) => {
  const href = slug ? `/projects/${slug}` : '#';

  return (
    <motion.article
      initial={{ opacity: 0, y: 24 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 1, delay, ease: EASE_FM }}
      viewport={{ once: true }}
      className="group border-t border-border pt-6 pb-10"
    >
      <div className="flex items-start justify-between gap-6 mb-5">
        <Link to={href} className="flex-1">
          <h3 className="display text-lg md:text-xl transition-transform duration-[600ms] ease-[cubic-bezier(0.16,1,0.3,1)] group-hover:translate-x-2">
            {title}
          </h3>
        </Link>
        <div className="flex gap-4">
          {githubUrl && (
            <a href={githubUrl} target="_blank" rel="noopener noreferrer" aria-label={`${title} source code`} className={iconLink}>
              <Github size={18} />
            </a>
          )}
          {liveUrl && (
            <a href={liveUrl} target="_blank" rel="noopener noreferrer" aria-label={`${title} live site`} className={iconLink}>
              <ExternalLink size={18} />
            </a>
          )}
        </div>
      </div>

      <Link to={href}>
        <p className="text-sm text-muted-foreground mb-6 max-w-prose line-clamp-3">{description}</p>
      </Link>

      <p className="eyebrow">{techStack.join(' / ')}</p>
    </motion.article>
  );
};

export default ProjectCard;
