---
name: motion-principles
description: Minimalist motion rules for this portfolio. Use for any animation, transition, or hover work.
---
# Minimalist Motion Engineering
- Never use abrupt, jerky linear transitions or overly fast bounce transitions.
- Every fade-in and structural movement follows cubic-bezier(0.16, 1, 0.3, 1).
- Stagger text reveals on page entry by 0.05s per line.
- Elements must never shift layout on scroll; animate only transform (translateY) and opacity.
